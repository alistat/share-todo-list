export { TextService } from './text.service';
export { TextDialogComponent } from './text-dialog/text-dialog.component';
export { CDialogButtonComponent } from './c-dialog-button/c-dialog-button.component';
export { TextModule } from './text.module';
