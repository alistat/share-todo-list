export interface DialogEvent {
  name?: string;
  head?: string;
  content?: string;
  visible?: boolean;
  trust?: boolean;
}
