export enum ListType {
  OPEN,
  PASSWORD,
  USER
}
