export interface Share {
  username: string;
  role: string;
}
