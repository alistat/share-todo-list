window.firebaseConnection = {
  apiKey: "AIzaSyCzBavnUoAKNBS5ArHSu4pMgXCRzA3fJuU",
  authDomain: "todoes-930d6.firebaseapp.com",
  databaseURL: "https://todoes-930d6.firebaseio.com",
  projectId: "todoes-930d6",
  storageBucket: "todoes-930d6.appspot.com",
  messagingSenderId: "38939854762"
};

window.firebaseFunctions = 'https://us-central1-todoes-930d6.cloudfunctions.net';
